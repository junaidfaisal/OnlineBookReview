import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

export function decodeToken(token) {
    return jwt.verify(token, process.env.TOKEN_SECRET_KEY);
}


export function createToken(user_id, username) {
    try {
        //console.log('SECRET_KEY:', process.env.SECRET_KEY);
       // console.log('TOKEN_SECRET_KEY:', process.env.TOKEN_SECRET_KEY);

        const expiresIn = 60 * 60;
        const  token = jwt.sign({ user_id, username }, process.env.TOKEN_SECRET_KEY, { expiresIn });
        //console.log('Generated Token:', token);
        return token;
      } catch (error) {
        console.error('Error creating token:', error);
      }
}