import { decodeToken } from "../utils/tokens.js"

function authenticate(req, res, next) {
    try {
        console.log("okkk");
        //console.log(req.headers);
        let tokenHeader = req.headers.authorization;
        //console.log(tokenHeader);
        // check token integrity
        if (!tokenHeader || !tokenHeader.startsWith("Bearer")) {
         //   return res.status(401).json({ message: "You're not authorized to do this action!" });
        }
        //console.log("ok");
       // tokenHeader = tokenHeader.split(' ')[1];
         console.log( tokenHeader);

        // verify token & store user_id in request to use it in the next controller
        const { user_id } = decodeToken(tokenHeader);
        req.user = { user_id };
        console.log(user_id);
        next();
    } catch (error) {
        return res.status(401).json({ message: "You're not authorized to do this action!" });
    }
}

export default authenticate;