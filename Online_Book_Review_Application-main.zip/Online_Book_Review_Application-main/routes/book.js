import { Router } from "express";
import * as bookControllers from "../controllers/book.js";

const router = Router();

router.get("/books", bookControllers.getAllBooks);
router.get("/books/byISBN/:ISBN", bookControllers.getBooksByISBN);
router.get("/books/byTitle/:Title", bookControllers.getBooksByTitle);
router.get("/books/byAuthor/:AurthorName", bookControllers.getBooksByAuthor);
router.post("/books", bookControllers.addBook);



export default router;