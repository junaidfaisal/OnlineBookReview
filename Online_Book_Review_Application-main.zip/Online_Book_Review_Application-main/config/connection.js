import dotenv from "dotenv";
import { Sequelize } from "sequelize";

dotenv.config();

/* export const sequelize = new Sequelize(
    process.env.DATABASE_NAME,
    process.env.DATABASE_USERNAME,
    process.env.DATABASE_PASSWORD,
    {
        host: process.env.DATABASE_HOST,
        dialect: 'mysql'
    }); */

    export const sequelize = new Sequelize({
        dialect: 'mysql',
        host: '127.0.0.1',
        port: 3306,
        username: 'root',
        password: '',
        database: 'test',
    });

export async function connectDB() {
    try {
         const connectedDataBase = await sequelize.sync();
        console.log("Connected Database!");
    } catch (error) {
        console.log("Failed connecting to database", { message: error.message });
    }
}